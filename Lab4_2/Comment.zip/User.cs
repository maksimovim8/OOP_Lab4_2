﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_2
{
    internal class User
    {
        public string Name { get; }
        public string Email { get; }
        public string Nickname { get; } //@nickname

        private List<Post> Posts = new List<Post>();


        public User(string name, string email, string nickname)
        {
            Name = name;
            Email = email;
            Nickname = nickname;
        }


        public Post CreatePost(string text)
        {
            Post post = new Post(Nickname, text);
            Posts.Add(post);
            return post;
        }


        public void DeletePost(Post post)
        {
            if (Posts.Remove(post))
            {
                Console.WriteLine("Post deleted.");
            }
            else
            {
                Console.WriteLine("You can`t delete this post.");
            }
        }

        //Перегляд 5 останніх постів юзера
        public void GetLastFivePost()
        {
            int lastPost = Posts.Count-1;
            int count = 0;

            foreach(Post post in Posts)
            {
                if (count == 5)
                {
                    break;
                }

                Posts[lastPost].PostInfo();
                count++;
                lastPost--;
            }
        }


        //Перегляд постів іншої людини
        public void ViewPost(User user) 
        {
            if (user == this)
            {
                Console.WriteLine("Chose another user");
                return;
            }
            Console.WriteLine("Latest posts of " + user.Nickname);
            user.GetLastFivePost();
        }


        public void LikePost(Post post)
        {
            post.Like();
            Console.WriteLine("Post liked");
        }



        public void CommentPost(Post post, string comment)
        {
            Comment newComment = new Comment(Nickname, comment);
            post.AddComment(newComment);

            Console.WriteLine("Comment added.");
        }
    }
}
