﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4_2
{
    class Post
    {
        public DateTime Date;
        public string Text;
        public int LikesCount;
        public List<Comment> Comments;
        public string Author;

        public Post(string author, string text)
        {
            Author = author;
            Text = text;
            LikesCount = 0;
            Date = DateTime.Now;
            Comments = new List<Comment>();
        }

        public void Like()
        {
            LikesCount++;
        }

        public void AddComment(Comment comment)
        {
            Comments.Add(comment);
        }
        
        public void PostInfo()
        {
            Console.WriteLine("---------------------------------");
            Console.WriteLine("User: " + Author);
            Console.WriteLine("Date: " + Date);
            Console.WriteLine(Text);
            Console.WriteLine("Likes: " + LikesCount);
            Console.WriteLine("Comments");

            foreach (Comment comment in Comments)
            {
                comment.DisplayInfo();
            }
            Console.WriteLine("---------------------------------");
        }
        

    }
}
